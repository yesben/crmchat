<?php
// +----------------------------------------------------------------------
// | CRMEB [ CRMEB赋能开发者，助力企业发展 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2016~2020 https://www.crmeb.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed CRMEB并不是自由软件，未经许可不能去掉CRMEB相关版权
// +----------------------------------------------------------------------
// | Author: CRMEB Team <admin@crmeb.com>
// +----------------------------------------------------------------------

namespace app\controller\admin;


use app\jobs\UniPush;
use app\services\ApplicationServices;
use app\services\chat\ChatUserServices;
use crmeb\services\uniPush\options\AndroidOptions;
use crmeb\services\uniPush\options\IosOptions;
use crmeb\services\uniPush\options\PushMessageOptions;
use crmeb\services\uniPush\options\PushOptions;
use crmeb\services\uniPush\PushMessage;
use crmeb\utils\Captcha;
use crmeb\utils\Character;
use crmeb\utils\Encrypter;
use crmeb\utils\Collection;
use think\facade\Db;
use think\facade\Log;
use think\facade\Route;
use think\helper\Str;
use Carbon\Carbon;

class Test
{
    protected $app;

//    public function index(Captcha $captcha)
//    {
//        $res = $captcha->create([], true);
//
//        echo '<img src="' . $res['img'] . '">';
//
//        dump($res['key']);
//    }

    public function resolvBaseUrl()
    {
        return 'https://restapi.getui.com/v2/';
    }

    public function url(string $path = '')
    {
        $baseUrl = $this->resolvBaseUrl();
        $base    = strstr($baseUrl, 'http') === false;
        return ($base ? $baseUrl : '') . ($path ? $base ? '/' . $path : $path : '');
    }

    public function index2()
    {
        $clientId = '6b37b5c8e81c145986c60c5af3d12894';
        /** @var PushMessage $uniPush */
        $uniPush = app()->make(PushMessage::class);
        $uniPush->config([
            'appId'        => 'j03CifWGQw75KVTUt3tyh1',
            'appKey'       => 'QEADCgxYbI6qmwRhxccyJ3',
            'masterSecret' => 'CehaJ5xnrr5zKqiT1Nbdr9'
        ]);
        $option                      = new PushOptions();
        $messageOption               = new PushMessageOptions();
        $messageOption->title        = '新消息来了';
        $messageOption->body         = '来了老弟！！';
        $messageOption->clickType    = 'payload';
        $messageOption->payload      = 'click_type';
        $messageOption->channelLevel = 4;

        $option->setAudience($clientId);

        $ios              = new IosOptions();
        $ios->body        = $messageOption->body;
        $ios->title       = $messageOption->title;
        $android          = new AndroidOptions();
        $android->body    = $messageOption->body;
        $android->title   = $messageOption->title;
        $android->payload = $android->title;
        $option->setPushChannel($android, $ios);
//        $option->pushMessage = [
//            'transmission' => json_encode(['title' => '新消息来了', 'body' => 's收到没,来了老弟！！', 'url' => '/pages/view/user/index'])
//        ];
//        $option->setPushMessage($messageOption);
        $res = $uniPush->push($option);
        dump($res->all(), $option->toArray());
    }

    public function index()
    {
        $clientId = '6b37b5c8e81c145986c60c5af3d12894';
        /** @var PushMessage $uniPush */
        $uniPush = app()->make(PushMessage::class);
//        $uniPush->config([
//            'appId'        => 'j03CifWGQw75KVTUt3tyh1',
//            'appKey'       => 'QEADCgxYbI6qmwRhxccyJ3',
//            'masterSecret' => 'CehaJ5xnrr5zKqiT1Nbdr9'
//        ]);
        $option                      = new PushOptions();
        $messageOption               = new PushMessageOptions();
        $messageOption->title        = '新消息来了';
        $messageOption->body         = '倩倩，收到没！！收到了给我回一句';
        $messageOption->clickType    = 'payload';
        $messageOption->payload      = 'click_type';
        $messageOption->channelLevel = 4;

        $option->setAudience($clientId);

        $ios              = new IosOptions();
        $ios->body        = $messageOption->body;
        $ios->title       = $messageOption->title;
        $android          = new AndroidOptions();
        $android->body    = $messageOption->body;
        $android->title   = $messageOption->title;
        $android->payload = $android->title;
        $option->setPushChannel($android, $ios);
        $option->pushMessage = [
            'transmission' => json_encode(['title' => '新消息来了', 'body' => 's收到没,来了老弟！！', 'url' => '/pages/view/user/index'])
        ];
        $option->setPushMessage($messageOption);
        $res = $uniPush->push($option);
        dump($res->all(), $option->toArray());
//
//        $res = UniPush::dispatchSece(10, [
//            ['nickname' => '新消息来了'],
//            $clientId,
//            [
//                'content'  => '来了老弟!' . date('Y-m-d H:i:s'),
//                'msn_type' => 1,
//                'other'    => [],
//            ],
//        ]);
//
//        dump($res);
    }

    public function rule()
    {
        $this->app = app();
        $rule      = request()->get('rule', 'api/admin');
        $this->app->route->setTestMode(true);
        $this->app->route->clear();


        $path = $this->app->getRootPath() . 'route' . DIRECTORY_SEPARATOR;


        $files = is_dir($path) ? scandir($path) : [];

        foreach ($files as $file) {
            if (strpos($file, '.php')) {
                include $path . $file;
            }
        }

        $ruleList = $this->app->route->getRuleList();

        $ruleNewList = [];
        foreach ($ruleList as $item) {
            if (Str::contains($item['rule'], $rule)) {
                $ruleNewList[] = $item;
            }
        }
        foreach ($ruleNewList as $key => &$value) {
            $only           = $value['option']['only'] ?? [];
            $route          = is_string($value['route']) ? explode('/', $value['route']) : [];
            $value['route'] = is_string($value['route']) ? $value['route'] : '';
            $action         = $route[count($route) - 1] ?? null;
            if ($only && $action && !in_array($action, $only)) {
                unset($ruleNewList[$key]);
            }
            $except = $value['option']['except'] ?? [];
            if ($except && $action && in_array($action, $except)) {
                unset($ruleNewList[$key]);
            }
        }
        echo "<html lang=\"zh-CN\">
<head>
    <title>路由地址列表</title>
</head>
<link rel='stylesheet' type='text/css' href='https://www.layuicdn.com/layui/css/layui.css' />
<body>
<div style='margin: 20px'>
<fieldset class=\"layui-elem-field layui-field-title\" style=\"margin-top: 20px;\">
  <legend>路由地址列表</legend>
</fieldset>
<div class=\"layui-form\">
  <table class=\"layui-table\">
    <thead>
      <tr>
        <th>请求方式</th>
        <th>接口地址</th>
        <th>接口名称</th>
        <th>接口方法</th>
      </tr>
    </thead>
    <tbody>
  ";
        $allAction = ['delete', 'index', 'update', 'edit', 'save', 'create', 'read'];
        foreach ($ruleNewList as $route) {
            $option = $route['option']['real_name'] ?? null;
            if (is_array($option)) {
                foreach ($allAction as $action) {
                    if (Str::contains($route['route'], $action)) {
                        $real_name = $option[$action] ?? '';
                    }
                }
            } else {
                $real_name = $option;
            }
            $rule = $route['rule'];
            echo "<tr>
<td>$route[method]</td>
<td>" . htmlspecialchars($rule) . "</td>
<td>$real_name</td>
<td>$route[route]</td>
</tr>";
        }
        echo "</table></div></div>";
    }
}
